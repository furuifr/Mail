/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_13;
    QWidget *widget_8;
    QGridLayout *gridLayout_10;
    QHBoxLayout *horizontalLayout_21;
    QLabel *label_12;
    QSpacerItem *horizontalSpacer_8;
    QVBoxLayout *verticalLayout_12;
    QLabel *personalNameLabel;
    QLabel *addressLabel;
    QSpacerItem *horizontalSpacer_7;
    QHBoxLayout *horizontalLayout;
    QPushButton *personImfBtn;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *quitBtn;
    QHBoxLayout *horizontalLayout_22;
    QListWidget *listWidget;
    QStackedWidget *stackedWidget;
    QWidget *pageWrite;
    QGridLayout *gridLayout_4;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget_3;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *sendMailBtn;
    QPushButton *saveDraftBtn;
    QHBoxLayout *horizontalLayout_5;
    QLabel *labelRecipient;
    QLineEdit *lineEditRecipient;
    QHBoxLayout *horizontalLayout_6;
    QLabel *labelTheme_2;
    QLineEdit *lineEditTheme;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label;
    QTextEdit *textEditContent;
    QWidget *pageReceive;
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label_15;
    QWidget *widget;
    QGridLayout *gridLayout_14;
    QHBoxLayout *horizontalLayout_3;
    QCheckBox *checkBox;
    QPushButton *deleteCompleteBtn;
    QPushButton *deleteCheckedBtn;
    QPushButton *markAllReadedBtn;
    QSpacerItem *horizontalSpacer_10;
    QFrame *line;
    QTableView *tableView;
    QWidget *pageBook;
    QGridLayout *gridLayout_15;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_16;
    QWidget *widget_4;
    QGridLayout *gridLayout_5;
    QHBoxLayout *horizontalLayout_8;
    QCheckBox *checkBoxAllBook;
    QPushButton *addContactBtn;
    QPushButton *pushButton_2;
    QPushButton *deleteContactBtn;
    QPushButton *deleteGroupBtn;
    QSpacerItem *horizontalSpacer_11;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_5;
    QFrame *line_6;
    QTableView *tableViewAllBook;
    QVBoxLayout *verticalLayout_4;
    QFrame *frame;
    QLabel *label_2;
    QListWidget *listWidgetBook;
    QWidget *pageDraftBox;
    QVBoxLayout *verticalLayout_14;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_17;
    QWidget *widget_5;
    QGridLayout *gridLayout_6;
    QHBoxLayout *horizontalLayout_10;
    QCheckBox *checkBoxAllDraft;
    QPushButton *deleteDraft;
    QComboBox *markDraftComboBox;
    QSpacerItem *horizontalSpacer_12;
    QFrame *line_3;
    QTableView *tableViewDraft;
    QWidget *pageSended;
    QGridLayout *gridLayout_12;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_3;
    QWidget *widget_6;
    QGridLayout *gridLayout_13;
    QGridLayout *gridLayout_7;
    QCheckBox *checkBoxAllSelect;
    QPushButton *deleteSendMailBtn;
    QSpacerItem *horizontalSpacer_9;
    QTableView *tableViewSended;
    QFrame *line_4;
    QWidget *pageRubbish;
    QGridLayout *gridLayout_11;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_6;
    QWidget *widget_7;
    QGridLayout *gridLayout_8;
    QHBoxLayout *horizontalLayout_23;
    QCheckBox *checkBox_2;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_6;
    QTableView *tableViewRubbish;
    QWidget *pageReadMail;
    QGridLayout *gridLayout_3;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_2;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *replyBtn;
    QPushButton *deleteMailBtn;
    QPushButton *addNowContactBtn;
    QComboBox *comboBoxMark;
    QHBoxLayout *horizontalLayout_13;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_4;
    QLabel *labelSender;
    QLabel *labelTIem;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_5;
    QLabel *labelTheme;
    QTextEdit *textEditReadContent;
    QWidget *pagePersonalIfm;
    QGridLayout *gridLayout_9;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_11;
    QHBoxLayout *horizontalLayout_19;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_10;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_7;
    QLineEdit *personalName;
    QPushButton *modifyName;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_18;
    QLabel *labelAddressShow;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_9;
    QLineEdit *phoneNum;
    QPushButton *pushButton_5;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_10;
    QLineEdit *password;
    QPushButton *pushButton_6;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_18;
    QLabel *comfirmPwdLabel;
    QLineEdit *comfirmPwd;
    QSpacerItem *verticalSpacer_6;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_20;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_8;
    QSpacerItem *horizontalSpacer_4;
    QWidget *pageReceiveBox;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(989, 617);
        Widget->setMinimumSize(QSize(699, 545));
        gridLayout = new QGridLayout(Widget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        widget_8 = new QWidget(Widget);
        widget_8->setObjectName(QStringLiteral("widget_8"));
        gridLayout_10 = new QGridLayout(widget_8);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        label_12 = new QLabel(widget_8);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_21->addWidget(label_12);

        horizontalSpacer_8 = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_8);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        personalNameLabel = new QLabel(widget_8);
        personalNameLabel->setObjectName(QStringLiteral("personalNameLabel"));
        QFont font;
        font.setPointSize(15);
        personalNameLabel->setFont(font);

        verticalLayout_12->addWidget(personalNameLabel);

        addressLabel = new QLabel(widget_8);
        addressLabel->setObjectName(QStringLiteral("addressLabel"));
        QFont font1;
        font1.setPointSize(9);
        addressLabel->setFont(font1);

        verticalLayout_12->addWidget(addressLabel);


        horizontalLayout_21->addLayout(verticalLayout_12);

        horizontalSpacer_7 = new QSpacerItem(408, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_7);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        personImfBtn = new QPushButton(widget_8);
        personImfBtn->setObjectName(QStringLiteral("personImfBtn"));

        horizontalLayout->addWidget(personImfBtn);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_5);

        quitBtn = new QPushButton(widget_8);
        quitBtn->setObjectName(QStringLiteral("quitBtn"));

        horizontalLayout->addWidget(quitBtn);


        horizontalLayout_21->addLayout(horizontalLayout);


        gridLayout_10->addLayout(horizontalLayout_21, 0, 0, 1, 1);


        verticalLayout_13->addWidget(widget_8);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        listWidget = new QListWidget(Widget);
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("\345\206\231\344\277\241\345\233\276\346\240\207");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QStringLiteral("../write_email (1).png"), QSize(), QIcon::Normal, QIcon::Off);
            icon.addFile(QStringLiteral(":/new/icons/write_email (1).png"), QSize(), QIcon::Normal, QIcon::On);
            icon.addFile(QStringLiteral("write_email.png"), QSize(), QIcon::Disabled, QIcon::Off);
            icon.addFile(QStringLiteral("write_email.png"), QSize(), QIcon::Disabled, QIcon::On);
            icon.addFile(QStringLiteral("write_email.png"), QSize(), QIcon::Active, QIcon::Off);
            icon.addFile(QStringLiteral("write_email (1).png"), QSize(), QIcon::Active, QIcon::On);
            icon.addFile(QStringLiteral("write_email.png"), QSize(), QIcon::Selected, QIcon::Off);
            icon.addFile(QStringLiteral("../write_email.png"), QSize(), QIcon::Selected, QIcon::On);
        }
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        QFont font2;
        font2.setPointSize(17);
        font2.setUnderline(false);
        QListWidgetItem *__qlistwidgetitem = new QListWidgetItem(listWidget);
        __qlistwidgetitem->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem->setFont(font2);
        __qlistwidgetitem->setBackground(brush);
        __qlistwidgetitem->setIcon(icon);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/new/icons/\344\270\213\350\275\275 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        icon1.addFile(QString::fromUtf8("../\344\270\213\350\275\275.png"), QSize(), QIcon::Normal, QIcon::On);
        icon1.addFile(QString::fromUtf8("../\344\270\213\350\275\275.png"), QSize(), QIcon::Selected, QIcon::On);
        QFont font3;
        font3.setPointSize(17);
        QListWidgetItem *__qlistwidgetitem1 = new QListWidgetItem(listWidget);
        __qlistwidgetitem1->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem1->setFont(font3);
        __qlistwidgetitem1->setIcon(icon1);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/new/icons/\351\200\232\350\256\257\345\275\225 (1).png"), QSize(), QIcon::Normal, QIcon::Off);
        icon2.addFile(QString::fromUtf8("../\351\200\232\350\256\257\345\275\225.png"), QSize(), QIcon::Normal, QIcon::On);
        QListWidgetItem *__qlistwidgetitem2 = new QListWidgetItem(listWidget);
        __qlistwidgetitem2->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem2->setFont(font3);
        __qlistwidgetitem2->setIcon(icon2);
        QFont font4;
        font4.setPointSize(12);
        QListWidgetItem *__qlistwidgetitem3 = new QListWidgetItem(listWidget);
        __qlistwidgetitem3->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem3->setFont(font4);
        QListWidgetItem *__qlistwidgetitem4 = new QListWidgetItem(listWidget);
        __qlistwidgetitem4->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem4->setFont(font4);
        QListWidgetItem *__qlistwidgetitem5 = new QListWidgetItem(listWidget);
        __qlistwidgetitem5->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem5->setFont(font4);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setMinimumSize(QSize(50, 70));
        listWidget->setFocusPolicy(Qt::NoFocus);
        listWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        listWidget->setIconSize(QSize(30, 30));
        listWidget->setSpacing(22);

        horizontalLayout_22->addWidget(listWidget);

        stackedWidget = new QStackedWidget(Widget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setFocusPolicy(Qt::StrongFocus);
        pageWrite = new QWidget();
        pageWrite->setObjectName(QStringLiteral("pageWrite"));
        gridLayout_4 = new QGridLayout(pageWrite);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        widget_3 = new QWidget(pageWrite);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setStyleSheet(QLatin1String("background-color: rgb(252, 175, 62,30);\n"
"\n"
""));
        layoutWidget = new QWidget(widget_3);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 10, 168, 33));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        sendMailBtn = new QPushButton(layoutWidget);
        sendMailBtn->setObjectName(QStringLiteral("sendMailBtn"));
        sendMailBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_4->addWidget(sendMailBtn);

        saveDraftBtn = new QPushButton(layoutWidget);
        saveDraftBtn->setObjectName(QStringLiteral("saveDraftBtn"));
        saveDraftBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_4->addWidget(saveDraftBtn);


        verticalLayout_3->addWidget(widget_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        labelRecipient = new QLabel(pageWrite);
        labelRecipient->setObjectName(QStringLiteral("labelRecipient"));

        horizontalLayout_5->addWidget(labelRecipient);

        lineEditRecipient = new QLineEdit(pageWrite);
        lineEditRecipient->setObjectName(QStringLiteral("lineEditRecipient"));

        horizontalLayout_5->addWidget(lineEditRecipient);


        verticalLayout_3->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        labelTheme_2 = new QLabel(pageWrite);
        labelTheme_2->setObjectName(QStringLiteral("labelTheme_2"));

        horizontalLayout_6->addWidget(labelTheme_2);

        lineEditTheme = new QLineEdit(pageWrite);
        lineEditTheme->setObjectName(QStringLiteral("lineEditTheme"));

        horizontalLayout_6->addWidget(lineEditTheme);


        verticalLayout_3->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label = new QLabel(pageWrite);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_7->addWidget(label);

        textEditContent = new QTextEdit(pageWrite);
        textEditContent->setObjectName(QStringLiteral("textEditContent"));

        horizontalLayout_7->addWidget(textEditContent);


        verticalLayout_3->addLayout(horizontalLayout_7);

        verticalLayout_3->setStretch(0, 2);
        verticalLayout_3->setStretch(1, 2);
        verticalLayout_3->setStretch(2, 2);
        verticalLayout_3->setStretch(3, 12);

        gridLayout_4->addLayout(verticalLayout_3, 0, 0, 1, 1);

        stackedWidget->addWidget(pageWrite);
        pageReceive = new QWidget();
        pageReceive->setObjectName(QStringLiteral("pageReceive"));
        gridLayout_2 = new QGridLayout(pageReceive);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_15 = new QLabel(pageReceive);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setStyleSheet(QStringLiteral("font: 17pt \"Ubuntu\";"));

        verticalLayout->addWidget(label_15);

        widget = new QWidget(pageReceive);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setAutoFillBackground(false);
        widget->setStyleSheet(QLatin1String("background-color: rgb(252, 175, 62,30);\n"
"\n"
""));
        gridLayout_14 = new QGridLayout(widget);
        gridLayout_14->setSpacing(6);
        gridLayout_14->setContentsMargins(11, 11, 11, 11);
        gridLayout_14->setObjectName(QStringLiteral("gridLayout_14"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        checkBox = new QCheckBox(widget);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_3->addWidget(checkBox);

        deleteCompleteBtn = new QPushButton(widget);
        deleteCompleteBtn->setObjectName(QStringLiteral("deleteCompleteBtn"));
        deleteCompleteBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_3->addWidget(deleteCompleteBtn);

        deleteCheckedBtn = new QPushButton(widget);
        deleteCheckedBtn->setObjectName(QStringLiteral("deleteCheckedBtn"));
        deleteCheckedBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_3->addWidget(deleteCheckedBtn);

        markAllReadedBtn = new QPushButton(widget);
        markAllReadedBtn->setObjectName(QStringLiteral("markAllReadedBtn"));
        markAllReadedBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_3->addWidget(markAllReadedBtn);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_10);

        horizontalLayout_3->setStretch(0, 1);
        horizontalLayout_3->setStretch(1, 1);
        horizontalLayout_3->setStretch(2, 1);
        horizontalLayout_3->setStretch(3, 1);
        horizontalLayout_3->setStretch(4, 9);

        gridLayout_14->addLayout(horizontalLayout_3, 0, 0, 1, 1);


        verticalLayout->addWidget(widget);

        line = new QFrame(pageReceive);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        tableView = new QTableView(pageReceive);
        tableView->setObjectName(QStringLiteral("tableView"));

        verticalLayout->addWidget(tableView);


        gridLayout_2->addLayout(verticalLayout, 0, 0, 1, 1);

        stackedWidget->addWidget(pageReceive);
        pageBook = new QWidget();
        pageBook->setObjectName(QStringLiteral("pageBook"));
        gridLayout_15 = new QGridLayout(pageBook);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QStringLiteral("gridLayout_15"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        label_16 = new QLabel(pageBook);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setStyleSheet(QStringLiteral("font: 17pt \"Ubuntu\";"));

        verticalLayout_9->addWidget(label_16);

        widget_4 = new QWidget(pageBook);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setStyleSheet(QStringLiteral("background-color: rgb(252, 175, 62,30);\\n\\n"));
        gridLayout_5 = new QGridLayout(widget_4);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        checkBoxAllBook = new QCheckBox(widget_4);
        checkBoxAllBook->setObjectName(QStringLiteral("checkBoxAllBook"));
        checkBoxAllBook->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_8->addWidget(checkBoxAllBook);

        addContactBtn = new QPushButton(widget_4);
        addContactBtn->setObjectName(QStringLiteral("addContactBtn"));
        addContactBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_8->addWidget(addContactBtn);

        pushButton_2 = new QPushButton(widget_4);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_8->addWidget(pushButton_2);

        deleteContactBtn = new QPushButton(widget_4);
        deleteContactBtn->setObjectName(QStringLiteral("deleteContactBtn"));
        deleteContactBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_8->addWidget(deleteContactBtn);

        deleteGroupBtn = new QPushButton(widget_4);
        deleteGroupBtn->setObjectName(QStringLiteral("deleteGroupBtn"));
        deleteGroupBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_8->addWidget(deleteGroupBtn);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_11);

        horizontalLayout_8->setStretch(0, 1);
        horizontalLayout_8->setStretch(1, 1);
        horizontalLayout_8->setStretch(2, 1);
        horizontalLayout_8->setStretch(3, 1);
        horizontalLayout_8->setStretch(4, 1);
        horizontalLayout_8->setStretch(5, 8);

        gridLayout_5->addLayout(horizontalLayout_8, 0, 0, 1, 1);


        verticalLayout_9->addWidget(widget_4);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        line_6 = new QFrame(pageBook);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout_5->addWidget(line_6);

        tableViewAllBook = new QTableView(pageBook);
        tableViewAllBook->setObjectName(QStringLiteral("tableViewAllBook"));

        verticalLayout_5->addWidget(tableViewAllBook);


        horizontalLayout_9->addLayout(verticalLayout_5);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        frame = new QFrame(pageBook);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label_2 = new QLabel(frame);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 0, 72, 36));
        QFont font5;
        font5.setPointSize(18);
        label_2->setFont(font5);

        verticalLayout_4->addWidget(frame);

        listWidgetBook = new QListWidget(pageBook);
        QListWidgetItem *__qlistwidgetitem6 = new QListWidgetItem(listWidgetBook);
        __qlistwidgetitem6->setTextAlignment(Qt::AlignCenter);
        __qlistwidgetitem6->setFont(font);
        listWidgetBook->setObjectName(QStringLiteral("listWidgetBook"));

        verticalLayout_4->addWidget(listWidgetBook);

        verticalLayout_4->setStretch(0, 1);
        verticalLayout_4->setStretch(1, 12);

        horizontalLayout_9->addLayout(verticalLayout_4);

        horizontalLayout_9->setStretch(0, 6);
        horizontalLayout_9->setStretch(1, 2);

        verticalLayout_9->addLayout(horizontalLayout_9);


        gridLayout_15->addLayout(verticalLayout_9, 0, 0, 1, 1);

        stackedWidget->addWidget(pageBook);
        pageDraftBox = new QWidget();
        pageDraftBox->setObjectName(QStringLiteral("pageDraftBox"));
        verticalLayout_14 = new QVBoxLayout(pageDraftBox);
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setContentsMargins(11, 11, 11, 11);
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        label_17 = new QLabel(pageDraftBox);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setStyleSheet(QStringLiteral("font: 17pt \"Ubuntu\";"));

        verticalLayout_6->addWidget(label_17);

        widget_5 = new QWidget(pageDraftBox);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setStyleSheet(QStringLiteral("background-color: rgb(252, 175, 62,30);\\n\\n"));
        gridLayout_6 = new QGridLayout(widget_5);
        gridLayout_6->setSpacing(6);
        gridLayout_6->setContentsMargins(11, 11, 11, 11);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        checkBoxAllDraft = new QCheckBox(widget_5);
        checkBoxAllDraft->setObjectName(QStringLiteral("checkBoxAllDraft"));
        checkBoxAllDraft->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_10->addWidget(checkBoxAllDraft);

        deleteDraft = new QPushButton(widget_5);
        deleteDraft->setObjectName(QStringLiteral("deleteDraft"));
        deleteDraft->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_10->addWidget(deleteDraft);

        markDraftComboBox = new QComboBox(widget_5);
        markDraftComboBox->addItem(QString());
        markDraftComboBox->addItem(QString());
        markDraftComboBox->addItem(QString());
        markDraftComboBox->setObjectName(QStringLiteral("markDraftComboBox"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(markDraftComboBox->sizePolicy().hasHeightForWidth());
        markDraftComboBox->setSizePolicy(sizePolicy);
        markDraftComboBox->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_10->addWidget(markDraftComboBox);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_12);


        gridLayout_6->addLayout(horizontalLayout_10, 0, 0, 1, 1);


        verticalLayout_6->addWidget(widget_5);

        line_3 = new QFrame(pageDraftBox);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_6->addWidget(line_3);

        tableViewDraft = new QTableView(pageDraftBox);
        tableViewDraft->setObjectName(QStringLiteral("tableViewDraft"));

        verticalLayout_6->addWidget(tableViewDraft);

        verticalLayout_6->setStretch(0, 1);
        verticalLayout_6->setStretch(1, 2);
        verticalLayout_6->setStretch(2, 1);
        verticalLayout_6->setStretch(3, 14);

        verticalLayout_14->addLayout(verticalLayout_6);

        stackedWidget->addWidget(pageDraftBox);
        pageSended = new QWidget();
        pageSended->setObjectName(QStringLiteral("pageSended"));
        pageSended->setStyleSheet(QStringLiteral(""));
        gridLayout_12 = new QGridLayout(pageSended);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        label_3 = new QLabel(pageSended);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setFont(font3);

        verticalLayout_7->addWidget(label_3);

        widget_6 = new QWidget(pageSended);
        widget_6->setObjectName(QStringLiteral("widget_6"));
        widget_6->setStyleSheet(QLatin1String("background-color: rgb(252, 175, 62,30);\n"
"\n"
""));
        gridLayout_13 = new QGridLayout(widget_6);
        gridLayout_13->setSpacing(6);
        gridLayout_13->setContentsMargins(11, 11, 11, 11);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        gridLayout_7 = new QGridLayout();
        gridLayout_7->setSpacing(6);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        checkBoxAllSelect = new QCheckBox(widget_6);
        checkBoxAllSelect->setObjectName(QStringLiteral("checkBoxAllSelect"));
        checkBoxAllSelect->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        gridLayout_7->addWidget(checkBoxAllSelect, 0, 0, 1, 1);

        deleteSendMailBtn = new QPushButton(widget_6);
        deleteSendMailBtn->setObjectName(QStringLiteral("deleteSendMailBtn"));
        deleteSendMailBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        gridLayout_7->addWidget(deleteSendMailBtn, 0, 1, 1, 1);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_9, 0, 2, 1, 1);

        gridLayout_7->setColumnMinimumWidth(0, 1);
        gridLayout_7->setColumnMinimumWidth(1, 2);
        gridLayout_7->setColumnMinimumWidth(2, 10);

        gridLayout_13->addLayout(gridLayout_7, 0, 0, 1, 1);


        verticalLayout_7->addWidget(widget_6);

        tableViewSended = new QTableView(pageSended);
        tableViewSended->setObjectName(QStringLiteral("tableViewSended"));

        verticalLayout_7->addWidget(tableViewSended);


        gridLayout_12->addLayout(verticalLayout_7, 0, 0, 1, 1);

        line_4 = new QFrame(pageSended);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        gridLayout_12->addWidget(line_4, 1, 0, 1, 1);

        stackedWidget->addWidget(pageSended);
        pageRubbish = new QWidget();
        pageRubbish->setObjectName(QStringLiteral("pageRubbish"));
        pageRubbish->setStyleSheet(QStringLiteral(""));
        gridLayout_11 = new QGridLayout(pageRubbish);
        gridLayout_11->setSpacing(6);
        gridLayout_11->setContentsMargins(11, 11, 11, 11);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        label_6 = new QLabel(pageRubbish);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font3);

        verticalLayout_8->addWidget(label_6);

        widget_7 = new QWidget(pageRubbish);
        widget_7->setObjectName(QStringLiteral("widget_7"));
        widget_7->setStyleSheet(QStringLiteral("background-color: rgb(252, 175, 62,30);\\n\\n"));
        gridLayout_8 = new QGridLayout(widget_7);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(10);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        checkBox_2 = new QCheckBox(widget_7);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        checkBox_2->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_23->addWidget(checkBox_2);

        pushButton = new QPushButton(widget_7);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_23->addWidget(pushButton);

        horizontalSpacer_6 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_6);

        horizontalLayout_23->setStretch(0, 1);
        horizontalLayout_23->setStretch(1, 2);
        horizontalLayout_23->setStretch(2, 10);

        gridLayout_8->addLayout(horizontalLayout_23, 0, 0, 1, 1);


        verticalLayout_8->addWidget(widget_7);

        tableViewRubbish = new QTableView(pageRubbish);
        tableViewRubbish->setObjectName(QStringLiteral("tableViewRubbish"));

        verticalLayout_8->addWidget(tableViewRubbish);


        gridLayout_11->addLayout(verticalLayout_8, 0, 0, 1, 1);

        stackedWidget->addWidget(pageRubbish);
        pageReadMail = new QWidget();
        pageReadMail->setObjectName(QStringLiteral("pageReadMail"));
        gridLayout_3 = new QGridLayout(pageReadMail);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        widget_2 = new QWidget(pageReadMail);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setStyleSheet(QStringLiteral("background-color: rgb(252, 175, 62,30);\\n\\n"));
        layoutWidget1 = new QWidget(widget_2);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(11, 10, 368, 33));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        replyBtn = new QPushButton(layoutWidget1);
        replyBtn->setObjectName(QStringLiteral("replyBtn"));
        replyBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_2->addWidget(replyBtn);

        deleteMailBtn = new QPushButton(layoutWidget1);
        deleteMailBtn->setObjectName(QStringLiteral("deleteMailBtn"));
        deleteMailBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_2->addWidget(deleteMailBtn);

        addNowContactBtn = new QPushButton(layoutWidget1);
        addNowContactBtn->setObjectName(QStringLiteral("addNowContactBtn"));
        addNowContactBtn->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_2->addWidget(addNowContactBtn);

        comboBoxMark = new QComboBox(layoutWidget1);
        comboBoxMark->addItem(QString());
        comboBoxMark->addItem(QString());
        comboBoxMark->addItem(QString());
        comboBoxMark->addItem(QString());
        comboBoxMark->setObjectName(QStringLiteral("comboBoxMark"));
        sizePolicy.setHeightForWidth(comboBoxMark->sizePolicy().hasHeightForWidth());
        comboBoxMark->setSizePolicy(sizePolicy);
        comboBoxMark->setStyleSheet(QStringLiteral("background-color: rgb(238, 238, 236);"));

        horizontalLayout_2->addWidget(comboBoxMark);


        verticalLayout_2->addWidget(widget_2);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(0);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_4 = new QLabel(pageReadMail);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_11->addWidget(label_4);

        labelSender = new QLabel(pageReadMail);
        labelSender->setObjectName(QStringLiteral("labelSender"));
        labelSender->setFont(font);

        horizontalLayout_11->addWidget(labelSender);

        horizontalLayout_11->setStretch(0, 1);
        horizontalLayout_11->setStretch(1, 12);

        horizontalLayout_13->addLayout(horizontalLayout_11);

        labelTIem = new QLabel(pageReadMail);
        labelTIem->setObjectName(QStringLiteral("labelTIem"));

        horizontalLayout_13->addWidget(labelTIem);

        horizontalLayout_13->setStretch(0, 4);
        horizontalLayout_13->setStretch(1, 1);

        verticalLayout_2->addLayout(horizontalLayout_13);

        line_2 = new QFrame(pageReadMail);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_2);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_5 = new QLabel(pageReadMail);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font5);

        horizontalLayout_12->addWidget(label_5);

        labelTheme = new QLabel(pageReadMail);
        labelTheme->setObjectName(QStringLiteral("labelTheme"));
        QFont font6;
        font6.setPointSize(20);
        labelTheme->setFont(font6);

        horizontalLayout_12->addWidget(labelTheme);

        horizontalLayout_12->setStretch(0, 1);
        horizontalLayout_12->setStretch(1, 11);

        verticalLayout_2->addLayout(horizontalLayout_12);

        textEditReadContent = new QTextEdit(pageReadMail);
        textEditReadContent->setObjectName(QStringLiteral("textEditReadContent"));
        textEditReadContent->setFont(font6);

        verticalLayout_2->addWidget(textEditReadContent);

        verticalLayout_2->setStretch(0, 2);
        verticalLayout_2->setStretch(1, 1);
        verticalLayout_2->setStretch(2, 1);
        verticalLayout_2->setStretch(3, 1);
        verticalLayout_2->setStretch(4, 12);

        gridLayout_3->addLayout(verticalLayout_2, 0, 0, 1, 1);

        stackedWidget->addWidget(pageReadMail);
        pagePersonalIfm = new QWidget();
        pagePersonalIfm->setObjectName(QStringLiteral("pagePersonalIfm"));
        gridLayout_9 = new QGridLayout(pagePersonalIfm);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        label_11 = new QLabel(pagePersonalIfm);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setFont(font3);

        verticalLayout_11->addWidget(label_11);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        horizontalSpacer = new QSpacerItem(58, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        verticalSpacer_5 = new QSpacerItem(20, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_5);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        label_7 = new QLabel(pagePersonalIfm);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_14->addWidget(label_7);

        personalName = new QLineEdit(pagePersonalIfm);
        personalName->setObjectName(QStringLiteral("personalName"));

        horizontalLayout_14->addWidget(personalName);

        modifyName = new QPushButton(pagePersonalIfm);
        modifyName->setObjectName(QStringLiteral("modifyName"));

        horizontalLayout_14->addWidget(modifyName);


        verticalLayout_10->addLayout(horizontalLayout_14);

        verticalSpacer = new QSpacerItem(20, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        label_18 = new QLabel(pagePersonalIfm);
        label_18->setObjectName(QStringLiteral("label_18"));

        horizontalLayout_15->addWidget(label_18);

        labelAddressShow = new QLabel(pagePersonalIfm);
        labelAddressShow->setObjectName(QStringLiteral("labelAddressShow"));

        horizontalLayout_15->addWidget(labelAddressShow);

        horizontalLayout_15->setStretch(0, 1);
        horizontalLayout_15->setStretch(1, 2);

        verticalLayout_10->addLayout(horizontalLayout_15);

        verticalSpacer_2 = new QSpacerItem(20, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_2);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_9 = new QLabel(pagePersonalIfm);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_16->addWidget(label_9);

        phoneNum = new QLineEdit(pagePersonalIfm);
        phoneNum->setObjectName(QStringLiteral("phoneNum"));

        horizontalLayout_16->addWidget(phoneNum);

        pushButton_5 = new QPushButton(pagePersonalIfm);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));

        horizontalLayout_16->addWidget(pushButton_5);


        verticalLayout_10->addLayout(horizontalLayout_16);

        verticalSpacer_3 = new QSpacerItem(20, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_3);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_10 = new QLabel(pagePersonalIfm);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_17->addWidget(label_10);

        password = new QLineEdit(pagePersonalIfm);
        password->setObjectName(QStringLiteral("password"));
        password->setEchoMode(QLineEdit::Password);

        horizontalLayout_17->addWidget(password);

        pushButton_6 = new QPushButton(pagePersonalIfm);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));

        horizontalLayout_17->addWidget(pushButton_6);


        verticalLayout_10->addLayout(horizontalLayout_17);

        verticalSpacer_4 = new QSpacerItem(20, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_4);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        comfirmPwdLabel = new QLabel(pagePersonalIfm);
        comfirmPwdLabel->setObjectName(QStringLiteral("comfirmPwdLabel"));

        horizontalLayout_18->addWidget(comfirmPwdLabel);

        comfirmPwd = new QLineEdit(pagePersonalIfm);
        comfirmPwd->setObjectName(QStringLiteral("comfirmPwd"));
        comfirmPwd->setEchoMode(QLineEdit::Password);

        horizontalLayout_18->addWidget(comfirmPwd);


        verticalLayout_10->addLayout(horizontalLayout_18);

        verticalSpacer_6 = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_6);


        horizontalLayout_19->addLayout(verticalLayout_10);

        horizontalSpacer_2 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_2);


        verticalLayout_11->addLayout(horizontalLayout_19);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        horizontalSpacer_3 = new QSpacerItem(128, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_3);

        pushButton_8 = new QPushButton(pagePersonalIfm);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));

        horizontalLayout_20->addWidget(pushButton_8);

        horizontalSpacer_4 = new QSpacerItem(138, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_4);


        verticalLayout_11->addLayout(horizontalLayout_20);


        gridLayout_9->addLayout(verticalLayout_11, 0, 0, 1, 1);

        stackedWidget->addWidget(pagePersonalIfm);
        pageReceiveBox = new QWidget();
        pageReceiveBox->setObjectName(QStringLiteral("pageReceiveBox"));
        stackedWidget->addWidget(pageReceiveBox);

        horizontalLayout_22->addWidget(stackedWidget);

        horizontalLayout_22->setStretch(0, 1);
        horizontalLayout_22->setStretch(1, 4);

        verticalLayout_13->addLayout(horizontalLayout_22);

        verticalLayout_13->setStretch(0, 1);
        verticalLayout_13->setStretch(1, 7);

        gridLayout->addLayout(verticalLayout_13, 0, 0, 1, 1);


        retranslateUi(Widget);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        label_12->setText(QApplication::translate("Widget", "\345\233\276\347\211\207", nullptr));
        personalNameLabel->setText(QApplication::translate("Widget", "\346\230\265\347\247\260", nullptr));
        addressLabel->setText(QApplication::translate("Widget", "\347\224\250\346\210\267\345\220\215", nullptr));
        personImfBtn->setText(QApplication::translate("Widget", "\344\270\252\344\272\272\344\277\241\346\201\257", nullptr));
        quitBtn->setText(QApplication::translate("Widget", "\346\263\250\351\224\200", nullptr));

        const bool __sortingEnabled = listWidget->isSortingEnabled();
        listWidget->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listWidget->item(0);
        ___qlistwidgetitem->setText(QApplication::translate("Widget", "\345\206\231\344\277\241", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = listWidget->item(1);
        ___qlistwidgetitem1->setText(QApplication::translate("Widget", "\346\224\266\344\277\241", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = listWidget->item(2);
        ___qlistwidgetitem2->setText(QApplication::translate("Widget", "\351\200\232\350\256\257\345\275\225", nullptr));
        QListWidgetItem *___qlistwidgetitem3 = listWidget->item(3);
        ___qlistwidgetitem3->setText(QApplication::translate("Widget", "\350\215\211\347\250\277\347\256\261", nullptr));
        QListWidgetItem *___qlistwidgetitem4 = listWidget->item(4);
        ___qlistwidgetitem4->setText(QApplication::translate("Widget", "\345\267\262\345\217\221\351\200\201", nullptr));
        QListWidgetItem *___qlistwidgetitem5 = listWidget->item(5);
        ___qlistwidgetitem5->setText(QApplication::translate("Widget", "\345\236\203\345\234\276\347\256\261", nullptr));
        listWidget->setSortingEnabled(__sortingEnabled);

        sendMailBtn->setText(QApplication::translate("Widget", "\345\217\221\351\200\201", nullptr));
        saveDraftBtn->setText(QApplication::translate("Widget", "\345\255\230\350\215\211\347\250\277", nullptr));
        labelRecipient->setText(QApplication::translate("Widget", "\346\224\266\344\273\266\344\272\272", nullptr));
        labelTheme_2->setText(QApplication::translate("Widget", "\344\270\273    \351\242\230", nullptr));
        label->setText(QApplication::translate("Widget", "\346\255\243    \346\226\207", nullptr));
        label_15->setText(QApplication::translate("Widget", "\346\224\266\344\273\266\347\256\261", nullptr));
        checkBox->setText(QApplication::translate("Widget", "\345\205\250\351\200\211", nullptr));
        deleteCompleteBtn->setText(QApplication::translate("Widget", "\345\275\273\345\272\225\345\210\240\351\231\244", nullptr));
        deleteCheckedBtn->setText(QApplication::translate("Widget", "\345\210\240\351\231\244", nullptr));
        markAllReadedBtn->setText(QApplication::translate("Widget", "\345\205\250\351\203\250\346\240\207\344\270\272\345\267\262\350\257\273", nullptr));
        label_16->setText(QApplication::translate("Widget", "\351\200\232\350\256\257\345\275\225", nullptr));
        checkBoxAllBook->setText(QApplication::translate("Widget", "\345\205\250\351\200\211", nullptr));
        addContactBtn->setText(QApplication::translate("Widget", "\346\267\273\345\212\240\350\201\224\347\263\273\344\272\272", nullptr));
        pushButton_2->setText(QApplication::translate("Widget", "\346\226\260\345\273\272\347\276\244\347\273\204", nullptr));
        deleteContactBtn->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\350\201\224\347\263\273\344\272\272", nullptr));
        deleteGroupBtn->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\347\276\244\347\273\204", nullptr));
        label_2->setText(QApplication::translate("Widget", "\347\276\244\347\273\204", nullptr));

        const bool __sortingEnabled1 = listWidgetBook->isSortingEnabled();
        listWidgetBook->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem6 = listWidgetBook->item(0);
        ___qlistwidgetitem6->setText(QApplication::translate("Widget", "\345\205\250\351\203\250", nullptr));
        listWidgetBook->setSortingEnabled(__sortingEnabled1);

        label_17->setText(QApplication::translate("Widget", "\350\215\211\347\250\277\347\256\261", nullptr));
        checkBoxAllDraft->setText(QApplication::translate("Widget", "\345\205\250\351\200\211", nullptr));
        deleteDraft->setText(QApplication::translate("Widget", "\345\210\240\351\231\244\350\215\211\347\250\277", nullptr));
        markDraftComboBox->setItemText(0, QApplication::translate("Widget", "\346\227\240\346\240\207\350\256\260", nullptr));
        markDraftComboBox->setItemText(1, QApplication::translate("Widget", "\346\240\207\344\270\272\346\230\237\346\240\207", nullptr));
        markDraftComboBox->setItemText(2, QApplication::translate("Widget", "\345\217\226\346\266\210\346\230\237\346\240\207", nullptr));

        label_3->setText(QApplication::translate("Widget", "\345\267\262\345\217\221\351\200\201", nullptr));
        checkBoxAllSelect->setText(QApplication::translate("Widget", "\345\205\250\351\200\211", nullptr));
        deleteSendMailBtn->setText(QApplication::translate("Widget", "\345\210\240\351\231\244", nullptr));
        label_6->setText(QApplication::translate("Widget", "\345\236\203\345\234\276\347\256\261", nullptr));
        checkBox_2->setText(QApplication::translate("Widget", "\345\205\250\351\200\211", nullptr));
        pushButton->setText(QApplication::translate("Widget", "\345\275\273\345\272\225\345\210\240\351\231\244", nullptr));
        replyBtn->setText(QApplication::translate("Widget", "\345\233\236\345\244\215", nullptr));
        deleteMailBtn->setText(QApplication::translate("Widget", "\345\210\240\351\231\244", nullptr));
        addNowContactBtn->setText(QApplication::translate("Widget", "\346\267\273\345\212\240\350\257\245\350\201\224\347\263\273\344\272\272", nullptr));
        comboBoxMark->setItemText(0, QApplication::translate("Widget", "\346\227\240\346\240\207\350\256\260", nullptr));
        comboBoxMark->setItemText(1, QApplication::translate("Widget", "\346\230\237\346\240\207\351\202\256\344\273\266", nullptr));
        comboBoxMark->setItemText(2, QApplication::translate("Widget", "\345\267\262\350\257\273\351\202\256\344\273\266", nullptr));
        comboBoxMark->setItemText(3, QApplication::translate("Widget", "\345\217\226\346\266\210\346\230\237\346\240\207", nullptr));

        label_4->setText(QApplication::translate("Widget", "\345\217\221\344\273\266\344\272\272:", nullptr));
        labelSender->setText(QApplication::translate("Widget", "\345\217\221\344\273\266\344\272\272", nullptr));
        labelTIem->setText(QApplication::translate("Widget", "\346\227\266\351\227\264", nullptr));
        label_5->setText(QApplication::translate("Widget", "\344\270\273\351\242\230:", nullptr));
        labelTheme->setText(QApplication::translate("Widget", "\344\270\273\351\242\230", nullptr));
        label_11->setText(QApplication::translate("Widget", "\344\270\252\344\272\272\344\277\241\346\201\257", nullptr));
        label_7->setText(QApplication::translate("Widget", "\347\224\250  \346\210\267 \345\220\215", nullptr));
        modifyName->setText(QApplication::translate("Widget", "\344\277\256\346\224\271", nullptr));
        label_18->setText(QApplication::translate("Widget", "\351\202\256\347\256\261\345\234\260\345\235\200", nullptr));
        labelAddressShow->setText(QApplication::translate("Widget", "\346\230\276\347\244\272\351\202\256\347\256\261\345\234\260\345\235\200", nullptr));
        label_9->setText(QApplication::translate("Widget", "\347\224\265\350\257\235\345\217\267\347\240\201", nullptr));
        pushButton_5->setText(QApplication::translate("Widget", "\344\277\256\346\224\271", nullptr));
        label_10->setText(QApplication::translate("Widget", "\345\257\206          \347\240\201", nullptr));
        pushButton_6->setText(QApplication::translate("Widget", "\344\277\256\346\224\271", nullptr));
        comfirmPwdLabel->setText(QApplication::translate("Widget", "\347\241\256\350\256\244\345\257\206\347\240\201", nullptr));
        pushButton_8->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
