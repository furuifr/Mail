#ifndef USER_H
#define USER_H
#include <QString>

class User
{
public:
    User();
    User(QString userName,QString pwd);

    QString getUserName();
    QString getPassword();

private:
    QString _userName;
    QString _password;

};

#endif // USER_H
