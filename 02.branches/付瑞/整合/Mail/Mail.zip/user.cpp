#include "user.h"

User::User()
{

}

User::User(QString userName,QString pwd)
    :_userName(userName),_password(pwd)
{}

QString User::getUserName()
{
    return _userName;
}

QString User::getPassword()
{
    return _password;
}
